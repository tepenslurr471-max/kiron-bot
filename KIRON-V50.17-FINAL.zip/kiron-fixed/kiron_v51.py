#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║           KIRON V51 - EXTENSION MODULE                           ║
║              Additional Features & Commands                       ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
"""

# ═══════════════════════════════════════════════════════════
# IMPORTS
# ═══════════════════════════════════════════════════════════

from telethon import events
import asyncio
import logging

# Import bot from main script
try:
    from __main__ import client as bot
    logger = logging.getLogger(__name__)
except ImportError:
    print("ERROR: This module must be imported from the main bot script!")
    print("Run: python bot.py")
    exit(1)

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════

# Command prefix - mudah diganti
cmd_prefix = "."

# ═══════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════

def get_emoji(name):
    """Get emoji - fallback jika tidak ada di main"""
    emojis = {
        'loader': '⏳',
        'check': '✅',
        'error': '❌',
        'warning': '⚠️',
    }
    return emojis.get(name, '•')

async def safe_edit(event, text):
    """Safe edit message"""
    try:
        await event.edit(text)
    except Exception as e:
        logger.error(f"Error editing message: {e}")
        try:
            await event.reply(text)
        except:
            pass

# ═══════════════════════════════════════════════════════════
# COMMANDS - CEK LIMIT
# ═══════════════════════════════════════════════════════════

@bot.on(events.NewMessage(outgoing=True, pattern=rf'^{cmd_prefix}ceklimit$'))
async def ceklimit_command(event):
    """
    Cek limit spam dari @SpamBot
    Usage: .ceklimit
    """
    try:
        await safe_edit(event, f"{get_emoji('loader')} Checking spam limit...")
        
        # Chat dengan SpamBot
        spambot = "@SpamBot"
        
        try:
            # Send message ke SpamBot
            await bot.send_message(spambot, "/start")
            
            # Wait for response
            await asyncio.sleep(2)
            
            # Get last message from SpamBot
            async for message in bot.iter_messages(spambot, limit=1):
                response_text = message.text
                
                # Mark as read
                await bot.send_read_acknowledge(spambot)
                
                # Format output
                output = (
                    f"{get_emoji('check')} **CEK LIMIT SPAM**\n"
                    f"══════════════════════\n"
                    f"{response_text}\n"
                    f"══════════════════════\n"
                    f"🤖 Source: @SpamBot"
                )
                
                await safe_edit(event, output)
                logger.info("Spam limit checked successfully")
                return
            
            # If no response
            await safe_edit(
                event,
                f"{get_emoji('warning')} No response from @SpamBot\n"
                f"Try again or check manually."
            )
            
        except Exception as e:
            logger.error(f"Error communicating with SpamBot: {e}")
            await safe_edit(
                event,
                f"{get_emoji('error')} Error: {str(e)}\n"
                f"Try checking @SpamBot manually."
            )
            
    except Exception as e:
        logger.error(f"Error in ceklimit command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

# ═══════════════════════════════════════════════════════════
# INITIALIZATION
# ═══════════════════════════════════════════════════════════

logger.info("Kiron V51 Extension Module loaded successfully!")
logger.info(f"Command prefix: {cmd_prefix}")
logger.info("Available commands:")
logger.info(f"  - {cmd_prefix}ceklimit - Check spam limit from @SpamBot")

print("═" * 60)
print("  KIRON V51 EXTENSION MODULE")
print("═" * 60)
print(f"✅ Module loaded successfully!")
print(f"📝 Command prefix: {cmd_prefix}")
print(f"🤖 Commands available:")
print(f"   • {cmd_prefix}ceklimit - Check spam limit")
print("═" * 60)
