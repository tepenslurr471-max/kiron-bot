#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║           KIRON USERBOT V50.0 PREMIUM EDITION                    ║
║              Telegram Premium with Custom Emoji                   ║
║                                                                   ║
║  Features: Spam Control, Utility, Intel, Premium Emoji,          ║
║            PM2 Integration, Advanced Error Handling              ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
"""

# ═══════════════════════════════════════════════════════════
# IMPORTS
# ═══════════════════════════════════════════════════════════

from telethon import TelegramClient, events, functions, types
from telethon.tl.functions.messages import ExportChatInviteRequest, GetFullChatRequest
from telethon.tl.functions.channels import CreateChannelRequest, LeaveChannelRequest, GetFullChannelRequest
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import MessageEntityMentionName, InputPeerChannel, InputPeerChat, Channel, Chat
from telethon.errors import (
    FloodWaitError, UserIsBlockedError, UserIdInvalidError,
    ChatAdminRequiredError, ChatWriteForbiddenError, InputUserDeactivatedError,
    PeerIdInvalidError, ChannelPrivateError, MessageNotModifiedError
)
from telethon.utils import get_peer_id, resolve_id
import asyncio
import datetime
import logging
import sys
import os
import json
import time
import re
from config import *

# ═══════════════════════════════════════════════════════════
# GLOBAL VARIABLES
# ═══════════════════════════════════════════════════════════

# AutoJoin Link Feature
autojoin_link_enabled = False

# ═══════════════════════════════════════════════════════════
# LOGGING SETUP
# ═══════════════════════════════════════════════════════════

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════
# PREMIUM EMOJI CONFIGURATION
# ═══════════════════════════════════════════════════════════

# Custom Emoji IDs untuk Telegram Premium
# Ganti dengan emoji premium ID Anda jika perlu
PREMIUM_EMOJIS = {
    'fire': '🔥',  # Animasi api premium
    'star': '⭐',  # Bintang berkilau
    'rocket': '🚀',  # Roket animasi
    'check': '✅',  # Centang hijau
    'cross': '❌',  # Silang merah
    'warning': '⚠️',  # Peringatan
    'lightning': '⚡',  # Petir
    'crown': '👑',  # Mahkota
    'gem': '💎',  # Berlian
    'robot': '🤖',  # Robot
    'chart': '📊',  # Grafik
    'target': '🎯',  # Target
    'broadcast': '📡',  # Broadcast
    'spam': '💣',  # Bom
    'note': '📝',  # Catatan
    'money': '💰',  # Uang
    'tools': '🛠️',  # Tools
    'stopwatch': '⏱️',  # Stopwatch
    'ping': '🏓',  # Ping pong
    'log': '📋',  # Log
    'user': '👤',  # User
    'group': '💬',  # Group
    'loader': '⏳',  # Loading
    'success': '🎉',  # Success
    'error': '💥',  # Error
    'shield': '🛡️',  # Shield
    'lock': '🔒',  # Lock
    'unlock': '🔓',  # Unlock
}

def get_emoji(key):
    """Get premium emoji or fallback"""
    if ENABLE_PREMIUM_EMOJI:
        return PREMIUM_EMOJIS.get(key, '')
    return ''

# ═══════════════════════════════════════════════════════════
# DATABASE MANAGEMENT
# ═══════════════════════════════════════════════════════════

class Database:
    """Simple JSON database handler"""
    
    def __init__(self, db_path=DATABASE_PATH):
        self.db_path = db_path
        self.data = self.load()
    
    def load(self):
        """Load database from JSON file"""
        try:
            if os.path.exists(self.db_path):
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return self._get_default_structure()
        except Exception as e:
            logger.error(f"Error loading database: {e}")
            return self._get_default_structure()
    
    def save(self):
        """Save database to JSON file"""
        try:
            with open(self.db_path, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Error saving database: {e}")
            return False
    
    def _get_default_structure(self):
        """Get default database structure"""
        return {
            'pay_msg': None,
            'notes': {},
            'bc_targets': [],
            'last_bc_msgs': [],
            'spam_delay': DEFAULT_SPAM_DELAY,
            'autojoin_enabled': True,
            'afk': {
                'enabled': False,
                'reason': None,
                'time': None
            },
            'logmembers_enabled': False,
            'join_monitor': {
                'count_today': 0,
                'last_reset': time.strftime('%Y-%m-%d'),
                'join_history': []
            },
            'stats': {
                'total_groups': 0,
                'total_broadcasts': 0,
                'total_spam': 0,
                'start_time': time.time()
            }
        }
    
    def get(self, key, default=None):
        """Get value from database"""
        return self.data.get(key, default)
    
    def set(self, key, value):
        """Set value in database"""
        self.data[key] = value
        self.save()
    
    def update(self, key, value):
        """Update nested value in database"""
        if isinstance(self.data.get(key), dict) and isinstance(value, dict):
            self.data[key].update(value)
        else:
            self.data[key] = value
        self.save()

# Initialize database
db = Database()

# ═══════════════════════════════════════════════════════════
# GLOBAL VARIABLES
# ═══════════════════════════════════════════════════════════

# Initialize Telegram Client
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

# Spam control
is_spamming = False
spam_tasks = []

# AFK tracking
afk_users = {}

# ═══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════

async def get_chat_info(chat):
    """Get comprehensive chat information"""
    try:
        if isinstance(chat, (Channel, Chat)):
            return chat
        entity = await client.get_entity(chat)
        return entity
    except Exception as e:
        logger.error(f"Error getting chat info: {e}")
        return None

async def get_user_info(user):
    """Get comprehensive user information"""
    try:
        entity = await client.get_entity(user)
        full_user = await client(GetFullUserRequest(entity))
        return entity, full_user
    except Exception as e:
        logger.error(f"Error getting user info: {e}")
        return None, None

async def safe_edit(event, text, **kwargs):
    """Safely edit message with error handling"""
    try:
        await event.edit(text, **kwargs)
    except MessageNotModifiedError:
        pass
    except Exception as e:
        logger.error(f"Error editing message: {e}")

async def safe_send(chat_id, message, **kwargs):
    """Safely send message with error handling"""
    try:
        return await client.send_message(chat_id, message, **kwargs)
    except Exception as e:
        logger.error(f"Error sending message to {chat_id}: {e}")
        return None

async def get_reply_message(event):
    """Get replied message safely"""
    try:
        if event.is_reply:
            return await event.get_reply_message()
    except Exception as e:
        logger.error(f"Error getting reply message: {e}")
    return None

def format_uptime(seconds):
    """Format uptime in human readable format"""
    days, remainder = divmod(int(seconds), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")
    
    return " ".join(parts)

async def log_to_group(message):
    """Send log message to logger group"""
    try:
        await safe_send(ID_GRUP_LOGGER, message)
    except Exception as e:
        logger.error(f"Error logging to group: {e}")

def check_and_reset_join_count():
    """Check dan reset join count jika sudah ganti hari"""
    join_monitor = db.get('join_monitor', {})
    today = time.strftime('%Y-%m-%d')
    last_reset = join_monitor.get('last_reset', '')
    
    if today != last_reset:
        # Reset counter karena hari baru
        join_monitor['count_today'] = 0
        join_monitor['last_reset'] = today
        join_monitor['join_history'] = []
        db.set('join_monitor', join_monitor)
        logger.info("Join counter reset (new day)")
    
    return join_monitor

async def increment_join_count(group_name, group_id):
    """Increment join count dan check limit"""
    # Reset jika hari baru
    join_monitor = check_and_reset_join_count()
    
    # Increment counter
    join_monitor['count_today'] = join_monitor.get('count_today', 0) + 1
    current_count = join_monitor['count_today']
    
    # Simpan ke history
    if 'join_history' not in join_monitor:
        join_monitor['join_history'] = []
    
    join_monitor['join_history'].append({
        'group': group_name,
        'id': group_id,
        'time': time.strftime('%H:%M:%S')
    })
    
    # Simpan ke database
    db.set('join_monitor', join_monitor)
    
    # Define limits
    LIMIT_WARNING = 15  # Kasih warning di 15
    LIMIT_MAX = 20      # Stop di 20
    
    # Notif simple ke logger
    if current_count == LIMIT_WARNING:
        await log_to_group(
            f"⚠️ **JOIN LIMIT WARNING**\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 Joined: `{current_count}/{LIMIT_MAX}` today\n"
            f"⏰ `{LIMIT_MAX - current_count}` left!"
        )
    elif current_count >= LIMIT_MAX:
        await log_to_group(
            f"🛑 **JOIN LIMIT REACHED!**\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 Total: `{current_count}` joins today\n"
            f"⏳ Wait 24h to join again"
        )
    
    return current_count

# ═══════════════════════════════════════════════════════════
# EVENT HANDLERS - CORE COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.help$'))
async def help_command(event):
    """Display help menu with premium emoji"""
    try:
        help_text = (
            f"{get_emoji('shield')} **KIRON USERBOT V50.11 PREMIUM** {get_emoji('crown')}\n"
            f"====================\n"
            f"{get_emoji('tools')} **ADMIN GRUP (MC STYLE)**\n"
            f"+ 🎤 `.kick` (reply) - Kick User\n"
            f"+ 🔇 `.mute` (reply) - Mute User\n"
            f"+ 🔈 `.unmute` (reply) - Unmute User\n"
            f"+ 🎫 `.ban` (reply) - Ban Permanen\n"
            f"+ 🚫 `.blok` (reply) - Blokir Kontak\n"
            f"+ ✅ `.unblok` (reply) - Unblok Kontak\n"
            f"+ 🎤 `.rekap` - Rekap Orderan MC\n\n"
            f"{get_emoji('tools')} **MANAJEMEN GRUP**\n"
            f"+ ➕ `.cg [nama]` - Buat Grup\n"
            f"+ 🚪 `.lg` - Keluar Grup\n"
            f"+ 📸 `.setgpic` (reply foto) - Ubah PP Grup\n"
            f"+ 🔗 `.autojoin on/off` - Auto Join dari Link\n"
            f"+ {get_emoji('chart')} `.stats` - Statistik Bot\n\n"
            f"{get_emoji('broadcast')} **SISTEM BROADCAST**\n"
            f"+ 📡 `.bc [teks/reply]` - BC Semua\n"
            f"+ {get_emoji('target')} `.bcselect [teks/reply]` - BC Target\n"
            f"+ ➕ `.addbc` - Tambah Target\n"
            f"+ {get_emoji('log')} `.listbc` - List Target\n"
            f"+ 🗑️ `.delbc` - Tarik BC\n"
            f"+ {get_emoji('cross')} `.clearbc` - Clear Target\n\n"
            f"{get_emoji('spam')} **SISTEM SPAM**\n"
            f"+ {get_emoji('stopwatch')} `.setdelay [detik]` - Set Delay\n"
            f"+ 💣 `.spam [jumlah] [teks]` - Spam\n"
            f"+ 🛑 `.stopspam` - Stop Spam\n\n"
            f"{get_emoji('money')} **PAYMENT & NOTES**\n"
            f"+ 📥 `.setpayment` - Set Payment\n"
            f"+ 📴 `.paymentoff` - Off Payment\n"
            f"+ {get_emoji('note')} `.save [nama]` - Save Note\n"
            f"+ 📖 `.notes` - List Notes\n"
            f"+ 🗑️ `.delnote [nama]` - Del Note\n\n"
            f"🎵 **MUSIC DOWNLOADER**\n"
            f"+ 🎧 `.music [judul]` - Search & Download\n"
            f"+ 🎬 `.video [judul]` - Download Video\n\n"
            f"{get_emoji('gem')} **UTILITY & INTEL**\n"
            f"+ 🆔 `.id` - Cek ID User/Grup\n"
            f"+ 📢 `.tagall [teks]` - Tag All Members\n"
            f"+ {get_emoji('log')} `.logmembers on/off` - Log Join/Leave\n"
            f"+ 😴 `.afk [alasan]` - Set AFK Mode\n"
            f"+ 🗑️ `.purge [angka]` - Hapus Pesan Massal\n"
            f"+ 🎭 `.steal` - Steal Media/Foto PP\n"
            f"+ 🧮 `.calc [expr]` - Kalkulator\n\n"
            f"{get_emoji('robot')} **SISTEM**\n"
            f"+ {get_emoji('ping')} `.ping` - Cek Ping\n"
            f"+ 🔄 `.autojoinon/off` - Toggle Logger\n"
            f"+ {get_emoji('check')} `.joinstatus` - Cek Join Status\n"
            f"+ 💾 `.backup` - Backup Session\n"
            f"+ 🔄 `.restart` - Restart Bot\n"
            f"===================="
        )
        await safe_edit(event, help_text)
        logger.info("Help menu displayed")
    except Exception as e:
        logger.error(f"Error in help command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.ping$'))
async def ping_command(event):
    """Ultra-fast ping command with premium emoji"""
    try:
        start_time = datetime.datetime.now()
        msg = await event.edit(f"{get_emoji('ping')} Pinging...")
        end_time = datetime.datetime.now()
        
        ping_ms = (end_time - start_time).total_seconds() * 1000
        
        await msg.edit(
            f"{get_emoji('lightning')} **PONG!** {get_emoji('rocket')}\n"
            f"{get_emoji('stopwatch')} **Speed:** `{ping_ms:.2f}ms`"
        )
        logger.info(f"Ping: {ping_ms:.2f}ms")
    except Exception as e:
        logger.error(f"Error in ping command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.stats$'))
async def stats_command(event):
    """Display comprehensive bot statistics"""
    try:
        await safe_edit(event, f"{get_emoji('loader')} Mengumpulkan statistik...")
        
        # Get current stats from database
        stats = db.get('stats', {})
        
        # Count groups asyncronously
        total_groups = 0
        total_channels = 0
        total_users = 0
        
        try:
            async for dialog in client.iter_dialogs():
                if dialog.is_group:
                    total_groups += 1
                elif dialog.is_channel:
                    total_channels += 1
                elif dialog.is_user:
                    total_users += 1
        except Exception as e:
            logger.error(f"Error counting dialogs: {e}")
        
        # Calculate uptime
        start_time = stats.get('start_time', time.time())
        uptime = format_uptime(time.time() - start_time)
        
        # Get other stats
        bc_targets = len(db.get('bc_targets', []))
        notes_count = len(db.get('notes', {}))
        total_bc = stats.get('total_broadcasts', 0)
        total_spam = stats.get('total_spam', 0)
        spam_delay = db.get('spam_delay', DEFAULT_SPAM_DELAY)
        
        # Logger status
        autojoin = db.get('autojoin_enabled', True)
        log_status = f"{get_emoji('check')} ON" if autojoin else f"{get_emoji('cross')} OFF"
        
        # Payment status
        pay_msg = db.get('pay_msg')
        pay_status = f"{get_emoji('check')} AKTIF" if pay_msg else f"{get_emoji('cross')} NONAKTIF"
        
        # AFK status
        afk_data = db.get('afk', {})
        afk_status = f"{get_emoji('check')} ON" if afk_data.get('enabled') else f"{get_emoji('cross')} OFF"
        
        stats_text = (
            f"{get_emoji('chart')} **BOT STATISTICS** {get_emoji('crown')}\n"
            f"====================\n"
            f"{get_emoji('robot')} **Status:** Running {get_emoji('check')}\n"
            f"{get_emoji('stopwatch')} **Uptime:** `{uptime}`\n"
            f"====================\n"
            f"{get_emoji('group')} **Conversations:**\n"
            f"+ Groups: `{total_groups}`\n"
            f"+ Channels: `{total_channels}`\n"
            f"+ Users: `{total_users}`\n"
            f"====================\n"
            f"{get_emoji('broadcast')} **Broadcast:**\n"
            f"+ Targets: `{bc_targets}`\n"
            f"+ Total Sent: `{total_bc}`\n"
            f"====================\n"
            f"{get_emoji('spam')} **Spam:**\n"
            f"+ Delay: `{spam_delay}s`\n"
            f"+ Total Sent: `{total_spam}`\n"
            f"====================\n"
            f"{get_emoji('note')} **Storage:**\n"
            f"+ Saved Notes: `{notes_count}`\n"
            f"====================\n"
            f"{get_emoji('tools')} **Settings:**\n"
            f"+ Auto Logger: {log_status}\n"
            f"+ Auto Payment: {pay_status}\n"
            f"+ AFK Mode: {afk_status}\n"
            f"====================\n"
            f"{get_emoji('success')} *Telegram Premium Edition*"
        )
        
        await safe_edit(event, stats_text)
        
        # Update stats in database
        stats['total_groups'] = total_groups
        db.set('stats', stats)
        
        logger.info("Stats displayed")
    except Exception as e:
        logger.error(f"Error in stats command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.calc\s+(.+)'))
async def calc_command(event):
    """Calculator command - evaluate mathematical expressions"""
    try:
        expression = event.pattern_match.group(1).strip()
        
        # Sanitize expression - only allow safe characters
        if not re.match(r'^[0-9+\-*/().%\s]+$', expression):
            await safe_edit(
                event,
                f"{get_emoji('warning')} Invalid expression!\n"
                f"Use only: numbers, +, -, *, /, %, (, )"
            )
            return
        
        try:
            # Evaluate expression safely
            result = eval(expression, {"__builtins__": {}}, {})
            
            await safe_edit(
                event,
                f"{get_emoji('gem')} **Calculator** 🧮\n"
                f"====================\n"
                f"**Expression:** `{expression}`\n"
                f"**Result:** `{result}`\n"
                f"===================="
            )
            logger.info(f"Calc: {expression} = {result}")
        except ZeroDivisionError:
            await safe_edit(event, f"{get_emoji('error')} Error: Division by zero!")
        except Exception as e:
            await safe_edit(event, f"{get_emoji('error')} Error: Invalid expression!")
            
    except Exception as e:
        logger.error(f"Error in calc command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.restart$'))
async def restart_command(event):
    """Restart bot with PM2 integration"""
    try:
        await safe_edit(
            event,
            f"{get_emoji('loader')} **Restarting bot...** {get_emoji('rocket')}\n"
            f"Bot will be back in a moment!"
        )
        
        logger.info("Bot restarting via .restart command")
        
        # Log restart to logger group
        await log_to_group(
            f"{get_emoji('warning')} **BOT RESTART**\n"
            f"====================\n"
            f"{get_emoji('stopwatch')} Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"{get_emoji('user')} Triggered by: User Command"
        )
        
        await asyncio.sleep(1)
        
        # PM2 compatible restart using os.execl
        # This will restart the process properly with PM2
        os.execl(sys.executable, sys.executable, *sys.argv)
        
    except Exception as e:
        logger.error(f"Error in restart command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.joinstatus$'))
async def joinstatus_command(event):
    """Check join status - with join monitor"""
    try:
        await safe_edit(event, f"{get_emoji('loader')} Checking join status...")
        
        # Reset counter jika hari baru
        join_monitor = check_and_reset_join_count()
        
        # Get join stats
        joins_today = join_monitor.get('count_today', 0)
        LIMIT_MAX = 20
        remaining = LIMIT_MAX - joins_today
        
        # Get autojoin status
        autojoin = db.get('autojoin_enabled', True)
        log_status = f"{get_emoji('check')} ON" if autojoin else f"{get_emoji('cross')} OFF"
        
        # Get payment status
        pay_msg = db.get('pay_msg')
        pay_status = f"{get_emoji('check')} AKTIF" if pay_msg else f"{get_emoji('cross')} NONAKTIF"
        
        # Get BC targets count
        bc_count = len(db.get('bc_targets', []))
        
        # Get notes count
        notes_count = len(db.get('notes', {}))
        
        # Get logmembers status
        logmembers = db.get('logmembers_enabled', False)
        logmem_status = f"{get_emoji('check')} ON" if logmembers else f"{get_emoji('cross')} OFF"
        
        # Join limit status
        if remaining <= 0:
            limit_status = "🛑 LIMIT REACHED"
        elif remaining <= 5:
            limit_status = f"⚠️ {remaining} LEFT"
        else:
            limit_status = f"✅ {remaining} LEFT"
        
        status_text = (
            f"{get_emoji('chart')} **JOIN & LOGGER STATUS** {get_emoji('shield')}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"{get_emoji('log')} **Auto Logger:** {log_status}\n"
            f"{get_emoji('money')} **Auto Payment:** {pay_status}\n"
            f"{get_emoji('user')} **Log Members:** {logmem_status}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📊 **Joins Today:** `{joins_today}/{LIMIT_MAX}`\n"
            f"🎯 **Status:** {limit_status}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"{get_emoji('target')} **BC Targets:** `{bc_count}`\n"
            f"{get_emoji('note')} **Saved Notes:** `{notes_count}`\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}"
        )
        
        await safe_edit(event, status_text)
        logger.info("Join status checked")
        
    except Exception as e:
        logger.error(f"Error in joinstatus command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.lg$'))
async def leave_group_command(event):
    """Leave group - fixed InputPeerChat error"""
    try:
        if not event.is_group and not event.is_channel:
            await safe_edit(event, f"{get_emoji('warning')} This command only works in groups!")
            return
        
        chat = await event.get_chat()
        chat_title = getattr(chat, 'title', 'Unknown')
        chat_id = event.chat_id
        
        await safe_edit(
            event,
            f"{get_emoji('warning')} Leaving group...\n"
            f"**{chat_title}**"
        )
        
        await asyncio.sleep(2)
        
        try:
            # Try to leave using LeaveChannelRequest (works for supergroups and channels)
            if hasattr(chat, 'megagroup') or isinstance(chat, Channel):
                await client(LeaveChannelRequest(chat))
            else:
                # For regular groups, use delete_dialog
                await client.delete_dialog(chat)
            
            # Log to logger group
            await log_to_group(
                f"{get_emoji('warning')} **LEFT GROUP**\n"
                f"====================\n"
                f"{get_emoji('group')} **Group:** `{chat_title}`\n"
                f"🆔 **ID:** `{chat_id}`\n"
                f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}"
            )
            
            logger.info(f"Left group: {chat_title} ({chat_id})")
            
        except Exception as e:
            logger.error(f"Error leaving group: {e}")
            # Try alternative method
            try:
                await client.delete_dialog(chat)
                await log_to_group(f"{get_emoji('check')} Left group: {chat_title}")
            except:
                await safe_edit(event, f"{get_emoji('error')} Failed to leave group!")
                
    except Exception as e:
        logger.error(f"Error in lg command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.autojoinon$'))
async def autojoin_on(event):
    """Enable auto join logger"""
    try:
        db.set('autojoin_enabled', True)
        await safe_edit(
            event,
            f"{get_emoji('check')} **Auto Join Logger: ON** {get_emoji('rocket')}"
        )
        logger.info("Auto join enabled")
    except Exception as e:
        logger.error(f"Error in autojoinon: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.autojoinoff$'))
async def autojoin_off(event):
    """Disable auto join logger"""
    try:
        db.set('autojoin_enabled', False)
        await safe_edit(
            event,
            f"{get_emoji('cross')} **Auto Join Logger: OFF**"
        )
        logger.info("Auto join disabled")
    except Exception as e:
        logger.error(f"Error in autojoinoff: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.backup$'))
async def backup_command(event):
    """Backup session file"""
    try:
        import shutil
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f'backup_{timestamp}.session'
        
        session_file = f'{SESSION_NAME}.session'
        
        if os.path.exists(session_file):
            shutil.copy(session_file, backup_file)
            await safe_edit(
                event,
                f"{get_emoji('check')} **Backup Created!** {get_emoji('gem')}\n"
                f"====================\n"
                f"📁 **File:** `{backup_file}`\n"
                f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}"
            )
            logger.info(f"Backup created: {backup_file}")
        else:
            await safe_edit(event, f"{get_emoji('error')} Session file not found!")
            
    except Exception as e:
        logger.error(f"Error in backup command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

# ═══════════════════════════════════════════════════════════
# BROADCAST COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.bc(?:select)?(?:\s|$)'))
async def broadcast_command(event):
    """Broadcast message - SIMPAN & KIRIM MESSAGE OBJECT!"""
    try:
        is_select = event.text.lower().startswith('.bcselect')
        
        # KUNCI: Tentukan apakah message object atau text
        msg_object = None
        msg_text = None
        
        if event.is_reply:
            # Reply = SIMPAN MESSAGE OBJECT!
            msg_object = await event.get_reply_message()
            if not msg_object:
                await safe_edit(
                    event, 
                    f"{get_emoji('warning')} Gagal ambil pesan!"
                )
                return
        else:
            # Text biasa
            cmd_parts = event.text.split(maxsplit=1)
            if len(cmd_parts) < 2:
                # Tidak ada text dan tidak reply = error
                await safe_edit(
                    event, 
                    f"{get_emoji('warning')} **Format salah!**\n\n"
                    f"Cara pakai:\n"
                    f"• `.bc [teks]` - BC text biasa\n"
                    f"• `.bc` (reply) - BC dengan format & foto\n"
                    f"• `.bcselect [teks]` - BC ke target\n"
                    f"• `.bcselect` (reply) - BC ke target dengan foto"
                )
                return
            msg_text = cmd_parts[1]
        
        await safe_edit(event, f"{get_emoji('broadcast')} **Broadcasting...** {get_emoji('rocket')}")
        
        # Get target list
        targets = []
        if is_select:
            targets = db.get('bc_targets', [])
            if not targets:
                await safe_edit(event, f"{get_emoji('warning')} No BC targets! Use `.addbc` first.")
                return
        else:
            try:
                async for dialog in client.iter_dialogs():
                    if dialog.is_group or dialog.is_channel:
                        targets.append(dialog.id)
            except Exception as e:
                logger.error(f"Error getting dialogs: {e}")
        
        # Broadcast to targets
        count, failed = 0, 0
        last_bc_msgs = []
        
        for chat_id in targets:
            try:
                # LOGIKA LAMA: Forward message object langsung (format lengkap!)
                if msg_object:
                    # Forward message object langsung!
                    sent = await client.send_message(chat_id, msg_object)
                else:
                    # Kirim text biasa
                    sent = await client.send_message(chat_id, msg_text)
                
                last_bc_msgs.append((chat_id, sent.id))
                count += 1
                await asyncio.sleep(BC_DELAY)
            except FloodWaitError as e:
                logger.warning(f"FloodWait: {e.seconds}s")
                await asyncio.sleep(e.seconds)
                failed += 1
            except Exception as e:
                logger.error(f"BC failed to {chat_id}: {e}")
                failed += 1
        
        # Save last BC messages
        db.set('last_bc_msgs', last_bc_msgs)
        
        # Update stats
        stats = db.get('stats', {})
        stats['total_broadcasts'] = stats.get('total_broadcasts', 0) + count
        db.set('stats', stats)
        
        result_text = (
            f"{get_emoji('check')} **Broadcast Complete!** {get_emoji('success')}\n"
            f"====================\n"
            f"{get_emoji('broadcast')} **Sent:** `{count}/{len(targets)}`\n"
        )
        
        if failed > 0:
            result_text += f"{get_emoji('warning')} **Failed:** `{failed}`\n"
        
        result_text += f"===================="
        
        await safe_edit(event, result_text)
        logger.info(f"Broadcast: {count} success, {failed} failed")
        
    except Exception as e:
        logger.error(f"Error in broadcast command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.addbc$'))
async def addbc_command(event):
    """Add current chat to BC targets"""
    try:
        chat_id = event.chat_id
        bc_targets = db.get('bc_targets', [])
        
        if chat_id in bc_targets:
            await safe_edit(event, f"{get_emoji('warning')} Chat already in BC targets!")
            return
        
        bc_targets.append(chat_id)
        db.set('bc_targets', bc_targets)
        
        chat = await event.get_chat()
        chat_name = getattr(chat, 'title', 'Private Chat')
        
        await safe_edit(
            event,
            f"{get_emoji('check')} **Added to BC Targets!** {get_emoji('target')}\n"
            f"====================\n"
            f"{get_emoji('group')} **Chat:** `{chat_name}`\n"
            f"🆔 **ID:** `{chat_id}`\n"
            f"{get_emoji('broadcast')} **Total Targets:** `{len(bc_targets)}`"
        )
        logger.info(f"Added BC target: {chat_id}")
        
    except Exception as e:
        logger.error(f"Error in addbc: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.listbc$'))
async def listbc_command(event):
    """List all BC targets"""
    try:
        bc_targets = db.get('bc_targets', [])
        
        if not bc_targets:
            await safe_edit(event, f"{get_emoji('warning')} No BC targets!")
            return
        
        await safe_edit(event, f"{get_emoji('loader')} Loading BC targets...")
        
        target_list = f"{get_emoji('broadcast')} **BC TARGET LIST** {get_emoji('target')}\n"
        target_list += f"====================\n"
        
        for i, chat_id in enumerate(bc_targets, 1):
            try:
                chat = await client.get_entity(chat_id)
                chat_name = getattr(chat, 'title', getattr(chat, 'username', 'Unknown'))
                target_list += f"{i}. **{chat_name}**\n   `{chat_id}`\n"
            except Exception as e:
                target_list += f"{i}. `{chat_id}` (Error)\n"
        
        target_list += f"====================\n"
        target_list += f"{get_emoji('chart')} **Total:** `{len(bc_targets)}`"
        
        await safe_edit(event, target_list)
        
    except Exception as e:
        logger.error(f"Error in listbc: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.clearbc$'))
async def clearbc_command(event):
    """Clear all BC targets"""
    try:
        count = len(db.get('bc_targets', []))
        db.set('bc_targets', [])
        
        await safe_edit(
            event,
            f"{get_emoji('check')} **BC Targets Cleared!**\n"
            f"Removed `{count}` targets."
        )
        logger.info(f"Cleared {count} BC targets")
        
    except Exception as e:
        logger.error(f"Error in clearbc: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.delbc$'))
async def delbc_command(event):
    """Delete last broadcast messages"""
    try:
        last_bc_msgs = db.get('last_bc_msgs', [])
        
        if not last_bc_msgs:
            await safe_edit(event, f"{get_emoji('warning')} No BC messages to delete!")
            return
        
        await safe_edit(event, f"{get_emoji('loader')} Deleting BC messages...")
        
        deleted = 0
        for chat_id, msg_id in last_bc_msgs:
            try:
                await client.delete_messages(chat_id, msg_id)
                deleted += 1
            except Exception as e:
                logger.error(f"Failed to delete BC message in {chat_id}: {e}")
        
        db.set('last_bc_msgs', [])
        
        await safe_edit(
            event,
            f"{get_emoji('check')} **BC Messages Deleted!** {get_emoji('success')}\n"
            f"Removed `{deleted}/{len(last_bc_msgs)}` messages."
        )
        logger.info(f"Deleted {deleted} BC messages")
        
    except Exception as e:
        logger.error(f"Error in delbc: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

# ═══════════════════════════════════════════════════════════
# SPAM CONTROL COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.setdelay\s+(\d+\.?\d*)'))
async def setdelay_command(event):
    """Set spam delay in real-time"""
    try:
        delay = float(event.pattern_match.group(1))
        
        if delay < 0.1:
            await safe_edit(event, f"{get_emoji('warning')} Minimum delay is 0.1 second!")
            return
        
        db.set('spam_delay', delay)
        
        await safe_edit(
            event,
            f"{get_emoji('check')} **Spam Delay Updated!** {get_emoji('stopwatch')}\n"
            f"====================\n"
            f"{get_emoji('stopwatch')} **New Delay:** `{delay}s`"
        )
        logger.info(f"Spam delay set to {delay}s")
        
    except Exception as e:
        logger.error(f"Error in setdelay: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.spam\s+(\d+)\s+(.+)'))
async def spam_command(event):
    """Spam messages with count and text"""
    global is_spamming, spam_tasks
    
    try:
        count = int(event.pattern_match.group(1))
        message = event.pattern_match.group(2)
        
        if count > MAX_SPAM_COUNT:
            await safe_edit(
                event,
                f"{get_emoji('warning')} Maximum spam count is `{MAX_SPAM_COUNT}`!"
            )
            return
        
        if count < 1:
            await safe_edit(event, f"{get_emoji('warning')} Count must be at least 1!")
            return
        
        spam_delay = db.get('spam_delay', DEFAULT_SPAM_DELAY)
        chat_id = event.chat_id
        
        await event.delete()
        
        is_spamming = True
        sent_count = 0
        
        try:
            for i in range(count):
                if not is_spamming:
                    break
                
                try:
                    await client.send_message(chat_id, message)
                    sent_count += 1
                    await asyncio.sleep(spam_delay)
                except FloodWaitError as e:
                    logger.warning(f"FloodWait: {e.seconds}s")
                    await asyncio.sleep(e.seconds)
                except Exception as e:
                    logger.error(f"Spam error: {e}")
                    break
            
            # Update stats
            stats = db.get('stats', {})
            stats['total_spam'] = stats.get('total_spam', 0) + sent_count
            db.set('stats', stats)
            
            # Send completion notification to logger group
            if sent_count > 0:
                await log_to_group(
                    f"{get_emoji('spam')} **SPAM COMPLETED**\n"
                    f"====================\n"
                    f"{get_emoji('chart')} **Sent:** `{sent_count}/{count}`\n"
                    f"{get_emoji('stopwatch')} **Delay:** `{spam_delay}s`"
                )
            
            logger.info(f"Spam completed: {sent_count}/{count} messages")
            
        finally:
            is_spamming = False
            
    except Exception as e:
        is_spamming = False
        logger.error(f"Error in spam command: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.stopspam$'))
async def stopspam_command(event):
    """Stop all spam processes instantly"""
    global is_spamming, spam_tasks
    
    try:
        was_spamming = is_spamming
        is_spamming = False
        
        # Cancel all spam tasks
        for task in spam_tasks:
            task.cancel()
        spam_tasks.clear()
        
        if was_spamming:
            await safe_edit(
                event,
                f"{get_emoji('check')} **Spam Stopped!** {get_emoji('warning')}\n"
                f"All spam processes terminated."
            )
            logger.info("Spam stopped by user")
        else:
            await safe_edit(event, f"{get_emoji('warning')} No active spam process!")
            
    except Exception as e:
        logger.error(f"Error in stopspam: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")


# ═══════════════════════════════════════════════════════════
# UTILITY & INTEL COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.id'))
async def id_command(event):
    """Get ID of user/group - supports reply/username/current chat"""
    try:
        # Check if replying to someone
        if event.is_reply:
            replied = await get_reply_message(event)
            if replied:
                user = await replied.get_sender()
                user_id = user.id
                first_name = getattr(user, 'first_name', 'Unknown')
                username = getattr(user, 'username', None)
                is_bot = getattr(user, 'bot', False)
                
                id_text = (
                    f"{get_emoji('user')} **USER INFORMATION** {get_emoji('gem')}\n"
                    f"====================\n"
                    f"**Name:** `{first_name}`\n"
                )
                
                if username:
                    id_text += f"**Username:** @{username}\n"
                
                id_text += (
                    f"🆔 **ID:** `{user_id}`\n"
                    f"🤖 **Bot:** {'Yes' if is_bot else 'No'}\n"
                    f"===================="
                )
                
                await safe_edit(event, id_text)
                return
        
        # Check if command has argument (username or ID)
        cmd_parts = event.text.split(maxsplit=1)
        if len(cmd_parts) > 1:
            target = cmd_parts[1].strip()
            
            try:
                # Try to get entity
                entity = await client.get_entity(target)
                
                if hasattr(entity, 'first_name'):  # User
                    user_id = entity.id
                    first_name = getattr(entity, 'first_name', 'Unknown')
                    username = getattr(entity, 'username', None)
                    is_bot = getattr(entity, 'bot', False)
                    
                    id_text = (
                        f"{get_emoji('user')} **USER INFORMATION** {get_emoji('gem')}\n"
                        f"====================\n"
                        f"**Name:** `{first_name}`\n"
                    )
                    
                    if username:
                        id_text += f"**Username:** @{username}\n"
                    
                    id_text += (
                        f"🆔 **ID:** `{user_id}`\n"
                        f"🤖 **Bot:** {'Yes' if is_bot else 'No'}\n"
                        f"===================="
                    )
                else:  # Group/Channel
                    chat_id = entity.id
                    chat_title = getattr(entity, 'title', 'Unknown')
                    username = getattr(entity, 'username', None)
                    members_count = getattr(entity, 'participants_count', 'Unknown')
                    
                    id_text = (
                        f"{get_emoji('group')} **GROUP INFORMATION** {get_emoji('crown')}\n"
                        f"====================\n"
                        f"**Title:** `{chat_title}`\n"
                    )
                    
                    if username:
                        id_text += f"**Username:** @{username}\n"
                    
                    id_text += (
                        f"🆔 **ID:** `{chat_id}`\n"
                        f"{get_emoji('user')} **Members:** `{members_count}`\n"
                        f"===================="
                    )
                
                await safe_edit(event, id_text)
                return
                
            except Exception as e:
                await safe_edit(event, f"{get_emoji('error')} Could not find user/group: {target}")
                return
        
        # No argument and no reply - show current chat info
        chat = await event.get_chat()
        
        if event.is_private:
            user_id = chat.id
            first_name = getattr(chat, 'first_name', 'Unknown')
            username = getattr(chat, 'username', None)
            
            id_text = (
                f"{get_emoji('user')} **CURRENT CHAT** {get_emoji('gem')}\n"
                f"====================\n"
                f"**Name:** `{first_name}`\n"
            )
            
            if username:
                id_text += f"**Username:** @{username}\n"
            
            id_text += (
                f"🆔 **ID:** `{user_id}`\n"
                f"===================="
            )
        else:
            chat_id = chat.id
            chat_title = getattr(chat, 'title', 'Unknown')
            username = getattr(chat, 'username', None)
            
            # Try to get member count
            try:
                full_chat = await client.get_entity(chat_id)
                members_count = getattr(full_chat, 'participants_count', 'Unknown')
            except:
                members_count = 'Unknown'
            
            id_text = (
                f"{get_emoji('group')} **CURRENT GROUP** {get_emoji('crown')}\n"
                f"====================\n"
                f"**Title:** `{chat_title}`\n"
            )
            
            if username:
                id_text += f"**Username:** @{username}\n"
            
            id_text += (
                f"🆔 **ID:** `{chat_id}`\n"
                f"{get_emoji('user')} **Members:** `{members_count}`\n"
                f"===================="
            )
        
        await safe_edit(event, id_text)
        logger.info(f"ID command executed in {chat_id if not event.is_private else 'private'}")
        
    except Exception as e:
        logger.error(f"Error in id command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.tagall(?:\s+(.+))?'))
async def tagall_command(event):
    """Tag all members - chunks of 5, delay 2s (anti-mute)"""
    try:
        if not event.is_group:
            await safe_edit(event, f"{get_emoji('warning')} This command only works in groups!")
            return
        
        message = event.pattern_match.group(1) or "Tag All"
        
        await event.delete()
        
        # Get all participants
        participants = []
        try:
            async for user in client.iter_participants(event.chat_id):
                if not user.bot and not user.deleted:
                    participants.append(user)
        except ChatAdminRequiredError:
            await safe_send(
                event.chat_id,
                f"{get_emoji('error')} Need admin rights to get member list!"
            )
            return
        except Exception as e:
            logger.error(f"Error getting participants: {e}")
            await safe_send(event.chat_id, f"{get_emoji('error')} Failed to get members!")
            return
        
        if not participants:
            await safe_send(event.chat_id, f"{get_emoji('warning')} No members to tag!")
            return
        
        # Tag in chunks
        chunk_size = TAGALL_CHUNK_SIZE
        total_chunks = (len(participants) + chunk_size - 1) // chunk_size
        
        for i in range(0, len(participants), chunk_size):
            chunk = participants[i:i+chunk_size]
            chunk_num = (i // chunk_size) + 1
            
            tag_text = f"{get_emoji('broadcast')} **{message}** ({chunk_num}/{total_chunks})\n"
            tag_text += "====================\n"
            
            for user in chunk:
                mention = f"[{user.first_name}](tg://user?id={user.id})"
                tag_text += f"{mention} "
            
            try:
                await client.send_message(event.chat_id, tag_text)
                await asyncio.sleep(TAGALL_DELAY)
            except FloodWaitError as e:
                logger.warning(f"FloodWait in tagall: {e.seconds}s")
                await asyncio.sleep(e.seconds)
            except Exception as e:
                logger.error(f"Error sending tag chunk: {e}")
        
        logger.info(f"Tagged {len(participants)} members in {total_chunks} chunks")
        
    except Exception as e:
        logger.error(f"Error in tagall command: {e}")
        await safe_send(event.chat_id, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.logmembers\s+(on|off)'))
async def logmembers_command(event):
    """Enable/disable member join/leave logging"""
    try:
        action = event.pattern_match.group(1).lower()
        
        if action == 'on':
            db.set('logmembers_enabled', True)
            status = f"{get_emoji('check')} ON"
        else:
            db.set('logmembers_enabled', False)
            status = f"{get_emoji('cross')} OFF"
        
        await safe_edit(
            event,
            f"{get_emoji('log')} **Member Logging:** {status}\n"
            f"Join/leave events will be logged to logger group."
        )
        logger.info(f"Member logging: {action}")
        
    except Exception as e:
        logger.error(f"Error in logmembers: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.afk(?:\s+(.+))?'))
async def afk_command(event):
    """Set AFK mode with optional reason"""
    try:
        reason = event.pattern_match.group(1) or "AFK"
        
        afk_data = {
            'enabled': True,
            'reason': reason,
            'time': time.time()
        }
        
        db.set('afk', afk_data)
        
        await safe_edit(
            event,
            f"😴 **AFK Mode Activated** {get_emoji('check')}\n"
            f"====================\n"
            f"{get_emoji('note')} **Reason:** `{reason}`\n"
            f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}\n"
            f"====================\n"
            f"Will auto-reply when mentioned."
        )
        logger.info(f"AFK mode enabled: {reason}")
        
    except Exception as e:
        logger.error(f"Error in afk command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.purge(?:\s+(\d+))?'))
async def purge_command(event):
    """Purge messages - delete mass messages"""
    try:
        if not event.is_reply:
            # Purge specific count from current position
            count_match = event.pattern_match.group(1)
            if not count_match:
                await safe_edit(event, f"{get_emoji('warning')} Reply to a message or specify count!")
                return
            
            count = int(count_match)
            if count > MAX_PURGE_MESSAGES:
                await safe_edit(
                    event,
                    f"{get_emoji('warning')} Maximum purge limit is `{MAX_PURGE_MESSAGES}` messages!"
                )
                return
            
            # Get message IDs to delete
            messages_to_delete = []
            async for message in client.iter_messages(event.chat_id, limit=count+1):
                messages_to_delete.append(message.id)
            
            # Delete messages
            try:
                await client.delete_messages(event.chat_id, messages_to_delete)
                
                # Send notification that auto-deletes
                notif = await client.send_message(
                    event.chat_id,
                    f"{get_emoji('check')} **Purged `{count}` messages!**"
                )
                await asyncio.sleep(3)
                await notif.delete()
                
                logger.info(f"Purged {count} messages")
            except Exception as e:
                await safe_edit(event, f"{get_emoji('error')} Failed to purge: {str(e)}")
                
        else:
            # Purge from replied message to current
            replied = await get_reply_message(event)
            if not replied:
                await safe_edit(event, f"{get_emoji('error')} Failed to get reply message!")
                return
            
            # Get all messages between reply and current
            messages_to_delete = []
            async for message in client.iter_messages(
                event.chat_id,
                min_id=replied.id - 1,
                max_id=event.id + 1
            ):
                messages_to_delete.append(message.id)
                if len(messages_to_delete) >= MAX_PURGE_MESSAGES:
                    break
            
            count = len(messages_to_delete)
            
            # Delete messages
            try:
                await client.delete_messages(event.chat_id, messages_to_delete)
                
                # Send notification that auto-deletes
                notif = await client.send_message(
                    event.chat_id,
                    f"{get_emoji('check')} **Purged `{count}` messages!**"
                )
                await asyncio.sleep(3)
                await notif.delete()
                
                logger.info(f"Purged {count} messages from reply")
            except Exception as e:
                await safe_send(event.chat_id, f"{get_emoji('error')} Failed to purge: {str(e)}")
                
    except Exception as e:
        logger.error(f"Error in purge command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.steal$'))
async def steal_command(event):
    """Steal media/profile photo - works on protected content"""
    try:
        if not event.is_reply:
            await safe_edit(event, f"{get_emoji('warning')} Reply to a message or user!")
            return
        
        replied = await get_reply_message(event)
        if not replied:
            await safe_edit(event, f"{get_emoji('error')} Failed to get reply message!")
            return
        
        await safe_edit(event, f"{get_emoji('loader')} Stealing content...")
        
        # Try to steal media from message
        if replied.media:
            try:
                # Download media
                file = await client.download_media(replied.media)
                
                if file:
                    # Send back the media
                    await client.send_file(
                        event.chat_id,
                        file,
                        caption=f"{get_emoji('check')} **Stolen!** {get_emoji('gem')}"
                    )
                    await event.delete()
                    
                    # Clean up downloaded file
                    try:
                        os.remove(file)
                    except:
                        pass
                    
                    logger.info("Media stolen successfully")
                else:
                    await safe_edit(event, f"{get_emoji('error')} Failed to download media!")
                    
            except Exception as e:
                logger.error(f"Error stealing media: {e}")
                await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")
        else:
            # Try to get profile photo
            try:
                user = await replied.get_sender()
                
                # Download profile photo
                photo = await client.download_profile_photo(user, file=bytes)
                
                if photo:
                    # Send back the photo
                    await client.send_file(
                        event.chat_id,
                        photo,
                        caption=f"{get_emoji('check')} **Profile Photo Stolen!** {get_emoji('crown')}"
                    )
                    await event.delete()
                    logger.info(f"Profile photo stolen from user {user.id}")
                else:
                    await safe_edit(event, f"{get_emoji('warning')} User has no profile photo!")
                    
            except Exception as e:
                logger.error(f"Error stealing profile photo: {e}")
                await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")
                
    except Exception as e:
        logger.error(f"Error in steal command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")


# ═══════════════════════════════════════════════════════════
# PAYMENT & NOTES COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.setpayment$'))
async def setpayment_command(event):
    """Set auto-payment message - SIMPAN MESSAGE OBJECT!"""
    try:
        if not event.is_reply:
            await safe_edit(
                event, 
                f"{get_emoji('warning')} **Reply Pesannya!**\n"
                f"Reply ke pesan payment dulu!"
            )
            return
        
        # KUNCI: SIMPAN MESSAGE OBJECT LANGSUNG!
        # Bukan cuma text, tapi SEMUA (format, media, emoji)
        pay_msg = await event.get_reply_message()
        
        # Simpan message object langsung
        db.set('pay_msg', pay_msg)
        
        await safe_edit(
            event,
            f"{get_emoji('check')} **Auto-Payment Set!** {get_emoji('money')}\n"
            f"====================\n"
            f"Akan terkirim otomatis saat join grup baru!\n"
            f"Format, foto, emoji tetap utuh!"
        )
        logger.info("Payment message set")
        
    except Exception as e:
        logger.error(f"Error in setpayment: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.paymentoff$'))
async def paymentoff_command(event):
    """Disable auto-payment"""
    try:
        db.set('pay_msg', None)
        
        await safe_edit(
            event,
            f"{get_emoji('cross')} **Auto-Payment Disabled!**"
        )
        logger.info("Payment disabled")
        
    except Exception as e:
        logger.error(f"Error in paymentoff: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.save\s+(\S+)'))
async def save_note_command(event):
    """
    Save note - SIMPAN MESSAGE OBJECT LANGSUNG (seperti broadcast!)
    """
    try:
        # Cek apakah reply ke pesan
        if not event.is_reply:
            await safe_edit(
                event, 
                f"{get_emoji('warning')} **Reply Pesannya!**\n"
                f"Balas pesan dulu baru ketik `.save [nama]`"
            )
            return
        
        # Ambil nama note
        note_name = event.pattern_match.group(1).strip()
        
        # Ambil replied message - SIMPAN LANGSUNG!
        replied_msg = await event.get_reply_message()
        
        # Load notes yang sudah ada
        notes = db.get('notes', {})
        
        # SIMPAN MESSAGE OBJECT LANGSUNG (seperti broadcast!)
        notes[note_name] = replied_msg
        db.set('notes', notes)
        
        # Info konfirmasi
        info_text = f"{get_emoji('check')} **Simpan Sukses!** {get_emoji('note')}\n"
        info_text += f"====================\n"
        info_text += f"📝 **Nama:** `.{note_name}`\n"
        
        if replied_msg.text:
            char_count = len(replied_msg.text)
            info_text += f"📄 **Text:** {char_count} karakter\n"
        
        if replied_msg.entities:
            entity_count = len(replied_msg.entities)
            info_text += f"✨ **Format:** {entity_count} entities\n"
        
        if replied_msg.media:
            media_type = type(replied_msg.media).__name__
            info_text += f"📎 **Media:** {media_type}\n"
        
        info_text += f"====================\n"
        info_text += f"💡 Panggil via: `.{note_name}`"
        
        await safe_edit(event, info_text)
        logger.info(f"Note saved: {note_name}")
        
    except Exception as e:
        logger.error(f"Error in save note: {e}")
        await safe_edit(
            event, 
            f"{get_emoji('error')} **Error!**\n"
            f"Contoh: `.save payment` (sambil reply)"
        )

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.notes$'))
async def list_notes_command(event):
    """List semua note yang tersimpan"""
    try:
        notes = db.get('notes', {})
        
        if not notes:
            await safe_edit(
                event, 
                f"{get_emoji('warning')} Belum ada note tersimpan!\n\n"
                f"Gunakan: `.save [nama]` (reply ke pesan)"
            )
            return
        
        notes_text = f"{get_emoji('note')} **DAFTAR NOTE TERSIMPAN**\n"
        notes_text += "====================\n"
        
        for i, (name, msg_obj) in enumerate(notes.items(), 1):
            # Cek apakah message object
            if hasattr(msg_obj, 'text'):
                # Cek ada media
                media_icon = "📎" if msg_obj.media else "📄"
                
                # Cek ada entities (format)
                format_icon = "✨" if msg_obj.entities else ""
                
                notes_text += f"{i}. {media_icon} `.{name}` {format_icon}\n"
                
                # Preview text (max 30 karakter)
                if msg_obj.text:
                    preview = msg_obj.text[:30]
                    if len(msg_obj.text) > 30:
                        preview += "..."
                    notes_text += f"   💬 {preview}\n"
            else:
                # Fallback untuk format lama (dict)
                notes_text += f"{i}. 📄 `.{name}`\n"
        
        notes_text += "====================\n"
        notes_text += f"📊 **Total:** `{len(notes)}` note\n\n"
        notes_text += "💡 **Cara pakai:** ketik `.nama_note`\n"
        notes_text += "📎 = Ada media | ✨ = Ada format"
        
        await safe_edit(event, notes_text)
        
    except Exception as e:
        logger.error(f"Error in list notes: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.delnote\s+(\S+)'))
async def delete_note_command(event):
    """Hapus note yang tersimpan"""
    try:
        note_name = event.pattern_match.group(1).strip()
        notes = db.get('notes', {})
        
        if note_name not in notes:
            await safe_edit(
                event,
                f"{get_emoji('warning')} Catatan `.{note_name}` gak ada!"
            )
            return
        
        # Hapus note dari database
        del notes[note_name]
        db.set('notes', notes)
        
        await safe_edit(
            event,
            f"{get_emoji('check')} Catatan `.{note_name}` dihapus!"
        )
        
        logger.info(f"Note deleted: {note_name}")
        
    except Exception as e:
        logger.error(f"Error in delete note: {e}")
        await safe_edit(
            event,
            f"{get_emoji('error')} Ketik: `.delnote [nama]`"
        )

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.(\w+)$'))
async def get_note_command(event):
    """
    Panggil note - FORWARD MESSAGE OBJECT LANGSUNG (seperti broadcast!)
    """
    try:
        note_name = event.pattern_match.group(1).strip()
        
        # List command yang harus di-skip
        skip_commands = [
            'help', 'ping', 'stats', 'calc', 'restart', 'joinstatus',
            'lg', 'id', 'afk', 'purge', 'steal', 'notes', 'backup',
            'autojoinon', 'autojoinoff', 'paymentoff', 'bc', 'bcselect',
            'addbc', 'listbc', 'clearbc', 'delbc', 'setdelay', 'spam',
            'stopspam', 'tagall', 'logmembers', 'setpayment', 'save',
            'delnote', 'cg', 'setgpic', 'autojoin', 'music', 'video', 'get'
        ]
        
        if note_name.lower() in skip_commands:
            return
        
        # Load notes
        notes = db.get('notes', {})
        
        if note_name not in notes:
            return
        
        saved_message = notes[note_name]
        
        # Hapus pesan command
        await event.delete()
        
        # FORWARD MESSAGE OBJECT LANGSUNG (seperti broadcast!)
        try:
            await client.send_message(event.chat_id, saved_message)
        except Exception as e:
            logger.error(f"Error sending note: {e}")
            # Fallback: kirim text saja
            if hasattr(saved_message, 'text') and saved_message.text:
                await client.send_message(event.chat_id, saved_message.text)
        
        logger.info(f"Note retrieved: {note_name}")
        
    except Exception as e:
        logger.error(f"Error in get note: {e}")

# ═══════════════════════════════════════════════════════════
# MUSIC DOWNLOADER COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.music\s+(.+)'))
async def music_command(event):
    """Search and download music from YouTube"""
    try:
        query = event.pattern_match.group(1).strip()
        
        await safe_edit(event, f"🎵 **Searching:** `{query}`...")
        
        try:
            import yt_dlp
        except ImportError:
            await safe_edit(
                event,
                f"{get_emoji('error')} **yt-dlp not installed!**\n\n"
                f"Install with:\n`pip install yt-dlp`"
            )
            return
        
        # Search YouTube
        ydl_opts = {
            'format': 'bestaudio/best',
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'default_search': 'ytsearch5',
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch5:{query}", download=False)
                
                if not info or 'entries' not in info or not info['entries']:
                    await safe_edit(event, f"{get_emoji('warning')} No results found!")
                    return
                
                # Get first result
                video = info['entries'][0]
                title = video.get('title', 'Unknown')
                url = video.get('url', video.get('webpage_url'))
                duration = video.get('duration', 0)
                uploader = video.get('uploader', 'Unknown')
                
                # Format duration (convert to int first!)
                duration_int = int(duration) if duration else 0
                minutes = duration_int // 60
                seconds = duration_int % 60
                duration_str = f"{minutes}:{seconds:02d}"
                
                await safe_edit(
                    event,
                    f"🎧 **Downloading...**\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎵 **Title:** `{title}`\n"
                    f"👤 **Uploader:** `{uploader}`\n"
                    f"⏱️ **Duration:** `{duration_str}`"
                )
                
                # Download audio
                output_file = f"{title[:50]}.mp3"
                download_opts = {
                    'format': 'bestaudio/best',
                    'outtmpl': output_file,
                    'quiet': True,
                    'no_warnings': True,
                    'postprocessors': [{
                        'key': 'FFmpegExtractAudio',
                        'preferredcodec': 'mp3',
                        'preferredquality': '192',
                    }],
                }
                
                with yt_dlp.YoutubeDL(download_opts) as ydl:
                    ydl.download([url])
                
                # Send audio file
                await client.send_file(
                    event.chat_id,
                    output_file,
                    caption=f"🎵 **{title}**\n👤 {uploader}",
                    attributes=[
                        types.DocumentAttributeAudio(
                            duration=int(duration),  # Convert to int
                            title=title,
                            performer=uploader
                        )
                    ]
                )
                
                await event.delete()
                
                # Cleanup
                try:
                    os.remove(output_file)
                except:
                    pass
                
                logger.info(f"Music downloaded: {title}")
                
        except Exception as e:
            await safe_edit(event, f"{get_emoji('error')} Download failed: `{str(e)}`")
            logger.error(f"Error downloading music: {e}")
            
    except Exception as e:
        logger.error(f"Error in music command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.video\s+(.+)'))
async def video_command(event):
    """Search and download video from YouTube"""
    try:
        query = event.pattern_match.group(1).strip()
        
        await safe_edit(event, f"🎬 **Searching:** `{query}`...")
        
        try:
            import yt_dlp
        except ImportError:
            await safe_edit(
                event,
                f"{get_emoji('error')} **yt-dlp not installed!**\n\n"
                f"Install with:\n`pip install yt-dlp`"
            )
            return
        
        # Search YouTube
        ydl_opts = {
            'format': 'best[height<=720]',
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'default_search': 'ytsearch5',
        }
        
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch5:{query}", download=False)
                
                if not info or 'entries' not in info or not info['entries']:
                    await safe_edit(event, f"{get_emoji('warning')} No results found!")
                    return
                
                # Get first result
                video = info['entries'][0]
                title = video.get('title', 'Unknown')
                url = video.get('url', video.get('webpage_url'))
                duration = video.get('duration', 0)
                uploader = video.get('uploader', 'Unknown')
                
                # Format duration (convert to int first!)
                duration_int = int(duration) if duration else 0
                minutes = duration_int // 60
                seconds = duration_int % 60
                duration_str = f"{minutes}:{seconds:02d}"
                
                await safe_edit(
                    event,
                    f"🎬 **Downloading...**\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"📹 **Title:** `{title}`\n"
                    f"👤 **Uploader:** `{uploader}`\n"
                    f"⏱️ **Duration:** `{duration_str}`"
                )
                
                # Download video
                output_file = f"{title[:50]}.mp4"
                download_opts = {
                    'format': 'best[height<=720]',
                    'outtmpl': output_file,
                    'quiet': True,
                    'no_warnings': True,
                }
                
                with yt_dlp.YoutubeDL(download_opts) as ydl:
                    ydl.download([url])
                
                # Send video file
                await client.send_file(
                    event.chat_id,
                    output_file,
                    caption=f"🎬 **{title}**\n👤 {uploader}",
                    attributes=[
                        types.DocumentAttributeVideo(
                            duration=int(duration),  # Convert to int
                            w=1280,
                            h=720
                        )
                    ]
                )
                
                await event.delete()
                
                # Cleanup
                try:
                    os.remove(output_file)
                except:
                    pass
                
                logger.info(f"Video downloaded: {title}")
                
        except Exception as e:
            await safe_edit(event, f"{get_emoji('error')} Download failed: `{str(e)}`")
            logger.error(f"Error downloading video: {e}")
            
    except Exception as e:
        logger.error(f"Error in video command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

# ═══════════════════════════════════════════════════════════
# GROUP MANAGEMENT COMMANDS
# ═══════════════════════════════════════════════════════════

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.kick(?:\s+(.+))?$'))
async def kick_command(event):
    """Kick user from group - MC Style (support reply & username)"""
    try:
        user = None
        username_arg = event.pattern_match.group(1)
        
        # Check if reply
        if event.is_reply:
            reply = await event.get_reply_message()
            user = await client.get_entity(reply.sender_id)
        # Check if username provided
        elif username_arg:
            try:
                user = await client.get_entity(username_arg.strip())
            except Exception as e:
                await event.edit(f"⚠️ User tidak ditemukan: `{username_arg}`")
                return
        else:
            await event.edit(
                f"⚠️ **Cara pakai:**\n"
                f"• `.kick` (reply pesan user)\n"
                f"• `.kick @username`\n"
                f"• `.kick 123456789` (user ID)"
            )
            return
        
        await event.edit(f"🎤 Durasi habis. Silakan keluar!")
        
        # Get chat entity to check type
        chat = await client.get_entity(event.chat_id)
        
        # Check if supergroup/channel or regular group
        if hasattr(chat, 'megagroup') or hasattr(chat, 'broadcast'):
            # Supergroup/Channel - use EditBannedRequest
            from telethon.tl.functions.channels import EditBannedRequest
            from telethon.tl.types import ChatBannedRights
            
            await client(EditBannedRequest(
                event.chat_id,
                user,
                ChatBannedRights(
                    until_date=None,
                    view_messages=True
                )
            ))
        else:
            # Regular group - use DeleteChatUser
            from telethon.tl.functions.messages import DeleteChatUserRequest
            
            await client(DeleteChatUserRequest(
                chat_id=event.chat_id,
                user_id=user
            ))
        
        logger.info(f"Kicked user {user.id} from {event.chat_id}")
        
    except ChatAdminRequiredError:
        await event.edit(f"{get_emoji('error')} Butuh admin!")
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error kick: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.mute(?:\s+(.+))?$'))
async def mute_command(event):
    """Mute user - MC Style (support reply & username)"""
    try:
        user = None
        username_arg = event.pattern_match.group(1)
        
        # Check if reply
        if event.is_reply:
            reply = await event.get_reply_message()
            user = await client.get_entity(reply.sender_id)
        # Check if username provided
        elif username_arg:
            try:
                user = await client.get_entity(username_arg.strip())
            except Exception as e:
                await event.edit(f"⚠️ User tidak ditemukan: `{username_arg}`")
                return
        else:
            await event.edit(
                f"⚠️ **Cara pakai:**\n"
                f"• `.mute` (reply pesan user)\n"
                f"• `.mute @username`\n"
                f"• `.mute 123456789` (user ID)"
            )
            return
        
        # Get chat entity to check type
        chat = await client.get_entity(event.chat_id)
        
        # Check if supergroup/channel
        if hasattr(chat, 'megagroup') or hasattr(chat, 'broadcast'):
            await event.edit(f"🔇 Mic dimatikan. Harap menyimak!")
            
            from telethon.tl.functions.channels import EditBannedRequest
            from telethon.tl.types import ChatBannedRights
            
            await client(EditBannedRequest(
                event.chat_id,
                user,
                ChatBannedRights(
                    until_date=None,
                    send_messages=True
                )
            ))
            
            logger.info(f"Muted user {user.id} in {event.chat_id}")
        else:
            # Regular group - mute not supported
            await event.edit(
                f"{get_emoji('warning')} **Mute tidak support di grup regular!**\n\n"
                f"💡 **Solusi:**\n"
                f"• Upgrade grup ke Supergroup\n"
                f"• Atau gunakan `.kick` untuk kick user"
            )
        
    except ChatAdminRequiredError:
        await event.edit(f"{get_emoji('error')} Butuh admin!")
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error mute: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.unmute(?:\s+(.+))?$'))
async def unmute_command(event):
    """Unmute user - MC Style (support reply & username)"""
    try:
        user = None
        username_arg = event.pattern_match.group(1)
        
        # Check if reply
        if event.is_reply:
            reply = await event.get_reply_message()
            user = await client.get_entity(reply.sender_id)
        # Check if username provided
        elif username_arg:
            try:
                user = await client.get_entity(username_arg.strip())
            except Exception as e:
                await event.edit(f"⚠️ User tidak ditemukan: `{username_arg}`")
                return
        else:
            await event.edit(
                f"⚠️ **Cara pakai:**\n"
                f"• `.unmute` (reply pesan user)\n"
                f"• `.unmute @username`\n"
                f"• `.unmute 123456789` (user ID)"
            )
            return
        
        # Get chat entity to check type
        chat = await client.get_entity(event.chat_id)
        
        # Check if supergroup/channel
        if hasattr(chat, 'megagroup') or hasattr(chat, 'broadcast'):
            await event.edit(f"🔈 Mic aktif. Silakan bicara!")
            
            from telethon.tl.functions.channels import EditBannedRequest
            from telethon.tl.types import ChatBannedRights
            
            await client(EditBannedRequest(
                event.chat_id,
                user,
                ChatBannedRights(
                    until_date=None,
                    send_messages=False
                )
            ))
            
            logger.info(f"Unmuted user {user.id} in {event.chat_id}")
        else:
            # Regular group - unmute not supported
            await event.edit(
                f"{get_emoji('warning')} **Unmute tidak support di grup regular!**"
            )
        
    except ChatAdminRequiredError:
        await event.edit(f"{get_emoji('error')} Butuh admin!")
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error unmute: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.ban(?:\s+(.+))?$'))
async def ban_command(event):
    """Ban user permanently - MC Style (support reply & username)"""
    try:
        user = None
        username_arg = event.pattern_match.group(1)
        
        # Check if reply
        if event.is_reply:
            reply = await event.get_reply_message()
            user = await client.get_entity(reply.sender_id)
        # Check if username provided
        elif username_arg:
            try:
                user = await client.get_entity(username_arg.strip())
            except Exception as e:
                await event.edit(f"⚠️ User tidak ditemukan: `{username_arg}`")
                return
        else:
            await event.edit(
                f"⚠️ **Cara pakai:**\n"
                f"• `.ban` (reply pesan user)\n"
                f"• `.ban @username`\n"
                f"• `.ban 123456789` (user ID)"
            )
            return
        
        await event.edit(f"🎫 Tiket dicabut. Blokir permanen!")
        
        # Get chat entity to check type
        chat = await client.get_entity(event.chat_id)
        
        # Check if supergroup/channel or regular group
        if hasattr(chat, 'megagroup') or hasattr(chat, 'broadcast'):
            # Supergroup/Channel - use EditBannedRequest
            from telethon.tl.functions.channels import EditBannedRequest
            from telethon.tl.types import ChatBannedRights
            
            await client(EditBannedRequest(
                event.chat_id,
                user,
                ChatBannedRights(
                    until_date=None,
                    view_messages=True,
                    send_messages=True,
                    send_media=True,
                    send_stickers=True,
                    send_gifs=True,
                    send_games=True,
                    send_inline=True,
                    embed_links=True
                )
            ))
        else:
            # Regular group - use DeleteChatUser (same as kick)
            from telethon.tl.functions.messages import DeleteChatUserRequest
            
            await client(DeleteChatUserRequest(
                chat_id=event.chat_id,
                user_id=user
            ))
        
        logger.info(f"Banned user {user.id} from {event.chat_id}")
        
    except ChatAdminRequiredError:
        await event.edit(f"{get_emoji('error')} Butuh admin!")
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error ban: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.blok$'))
async def block_command(event):
    """Block contact"""
    try:
        if not event.is_reply:
            await event.edit(f"⚠️ Reply targetnya!")
            return
        
        reply = await event.get_reply_message()
        user = await client.get_entity(reply.sender_id)
        
        from telethon.tl.functions.contacts import BlockRequest
        
        await client(BlockRequest(user))
        await event.edit(f"🚫 Kontak diblokir. Akses ditutup!")
        
        logger.info(f"Blocked user {user.id}")
        
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error block: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.unblok$'))
async def unblock_command(event):
    """Unblock contact"""
    try:
        if not event.is_reply:
            await event.edit(f"⚠️ Reply targetnya!")
            return
        
        reply = await event.get_reply_message()
        user = await client.get_entity(reply.sender_id)
        
        from telethon.tl.functions.contacts import UnblockRequest
        
        await client(UnblockRequest(user))
        await event.edit(f"✅ Blokir dibuka. Akses dipulihkan.")
        
        logger.info(f"Unblocked user {user.id}")
        
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error unblock: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.rekap$'))
async def rekap_command(event):
    """Rekap orderan MC dari logger group"""
    try:
        await event.edit(f"{get_emoji('loader')} Mengambil data...")
        
        # ID grup logger (dari config atau hardcode)
        logger_group_id = ID_GRUP_LOGGER if 'ID_GRUP_LOGGER' in globals() else -5112643953
        
        # Get today's date with timezone
        import pytz
        tz = pytz.timezone('Asia/Jakarta')  # Timezone Indonesia
        now = datetime.datetime.now(tz)
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        
        orderan_list = []
        total = 0
        
        # Iterate messages from today
        try:
            async for message in client.iter_messages(
                logger_group_id,
                limit=200  # Check last 200 messages
            ):
                # Check if message is from today
                if message.date.date() < today_start.date():
                    break  # Stop if we reached yesterday
                
                # Check if message contains AUTO JOIN SUCCESS
                if message.text and 'AUTO JOIN SUCCESS' in message.text.upper():
                    total += 1
                    waktu = message.date.astimezone(tz).strftime("%H:%M:%S")
                    orderan_list.append(f"• {waktu}")
        except Exception as e:
            logger.error(f"Error iterating messages: {e}")
            await event.edit(f"{get_emoji('error')} Error akses logger group: {str(e)}")
            return
        
        # Format output
        if total > 0:
            list_text = "\n".join(orderan_list)
            output = (
                f"🎤 **REKAP ORDERAN MC HARI INI**\n"
                f"══════════════════════\n"
                f"{list_text}\n"
                f"══════════════════════\n"
                f"📊 **Total Orderan:** `{total}`\n"
                f"#StayAmanah #SEMANGAT KIRON"
            )
        else:
            output = (
                f"🎤 **REKAP ORDERAN MC HARI INI**\n"
                f"══════════════════════\n"
                f"Belum ada orderan hari ini.\n"
                f"══════════════════════\n"
                f"📊 **Total Orderan:** `0`\n"
                f"#StayAmanah #SEMANGAT KIRON"
            )
        
        await event.edit(output)
        logger.info(f"Rekap generated: {total} orders")
        
    except Exception as e:
        await event.edit(f"{get_emoji('error')} Error: {str(e)}")
        logger.error(f"Error rekap: {e}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.cg\s+(.+)'))
async def create_group_command(event):
    """Create a new group"""
    try:
        group_name = event.pattern_match.group(1).strip()
        
        await safe_edit(event, f"{get_emoji('loader')} Creating group...")
        
        try:
            result = await client(CreateChannelRequest(
                title=group_name,
                about="Created by Kiron Premium Userbot",
                megagroup=True
            ))
            
            created_chat = result.chats[0]
            
            # Get invite link
            try:
                invite = await client(ExportChatInviteRequest(peer=created_chat.id))
                invite_link = invite.link
            except:
                invite_link = "Failed to get invite link"
            
            await safe_edit(
                event,
                f"{get_emoji('check')} **Group Created!** {get_emoji('success')}\n"
                f"====================\n"
                f"{get_emoji('group')} **Name:** `{group_name}`\n"
                f"🆔 **ID:** `{created_chat.id}`\n"
                f"🔗 **Link:** {invite_link}\n"
                f"===================="
            )
            
            logger.info(f"Group created: {group_name} ({created_chat.id})")
            
        except Exception as e:
            await safe_edit(event, f"{get_emoji('error')} Failed to create group: {str(e)}")
            logger.error(f"Error creating group: {e}")
            
    except Exception as e:
        logger.error(f"Error in cg command: {e}")
        await safe_edit(event, f"{get_emoji('error')} Error: {str(e)}")

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.setgpic$'))
async def set_group_pic_command(event):
    """Set group profile picture - Ultra simple version"""
    reply = await event.get_reply_message()
    if not reply or not reply.photo:
        return await event.edit(f"{get_emoji('warning')} Reply ke foto dulu!")

    await event.edit(f"{get_emoji('loader')} Sedang diproses...")
    
    try:
        # Download photo ke file REAL (bukan bytes)
        photo_path = await reply.download_media(file="temp_groupphoto.jpg")
        
        if not photo_path:
            return await event.edit(f"{get_emoji('error')} Gagal download foto!")
        
        # Upload file
        await event.edit(f"{get_emoji('loader')} Uploading...")
        uploaded = await client.upload_file(photo_path)
        
        # Set as group photo
        await event.edit(f"{get_emoji('loader')} Setting photo...")
        from telethon.tl.functions.messages import EditChatPhotoRequest
        
        await client(EditChatPhotoRequest(
            chat_id=event.chat_id,
            photo=uploaded
        ))
        
        await event.edit(f"{get_emoji('check')} **PP GRUP BERHASIL DIUBAH!** {get_emoji('success')}")
        logger.info(f"Group photo changed in {event.chat_id}")
        
    except FloodWaitError as e:
        await event.edit(f"{get_emoji('warning')} FloodWait! Tunggu {e.seconds} detik...")
        
    except ChatAdminRequiredError:
        await event.edit(f"{get_emoji('error')} Butuh admin!")
        
    except Exception as e:
        error = str(e)
        if "CHAT_NOT_MODIFIED" in error:
            await event.edit(f"{get_emoji('warning')} PP sudah sama!")
        elif "PHOTO_INVALID" in error:
            await event.edit(f"{get_emoji('error')} Foto tidak valid!")
        elif "PHOTO_EXT_INVALID" in error:
            await event.edit(f"{get_emoji('error')} Format foto tidak didukung! Pakai JPG/PNG")
        else:
            await event.edit(f"{get_emoji('error')} Error: `{error}`")
        logger.error(f"Error setgpic: {e}")
            
    finally:
        # Cleanup
        import os
        try:
            if os.path.exists("temp_groupphoto.jpg"):
                os.remove("temp_groupphoto.jpg")
        except:
            pass

@client.on(events.NewMessage(outgoing=True, pattern=r'^\.autojoin (on|off)$'))
async def toggle_autojoin_link(event):
    """Toggle autojoin dari link grup"""
    global autojoin_link_enabled
    
    action = event.pattern_match.group(1).lower()
    
    if action == 'on':
        autojoin_link_enabled = True
        await event.edit(
            f"{get_emoji('check')} **AutoJoin Link: ON** {get_emoji('success')}\n"
            f"Bot akan auto join kalau ada yang kirim link grup!"
        )
    else:
        autojoin_link_enabled = False
        await event.edit(
            f"{get_emoji('cross')} **AutoJoin Link: OFF**\n"
            f"Bot tidak akan auto join dari link."
        )
    
    logger.info(f"AutoJoin link: {autojoin_link_enabled}")


@client.on(events.NewMessage(incoming=True))
async def auto_join_from_link(event):
    """Auto join kalau ada yang kirim link grup"""
    global autojoin_link_enabled
    
    # Skip kalau fitur off
    if not autojoin_link_enabled:
        return
    
    # Hanya terima dari PM (private message)
    if not event.is_private:
        return
    
    # Ambil text message
    text = event.message.text or ""
    
    # Skip kalau tidak ada text
    if not text:
        return
    
    # Cari link grup
    import re
    
    # Pattern link Telegram grup (6 patterns!)
    patterns = [
        r'https?://t\.me/joinchat/([A-Za-z0-9_-]+)',
        r'https?://t\.me/\+([A-Za-z0-9_-]+)',
        r'https?://telegram\.me/joinchat/([A-Za-z0-9_-]+)',
        r'https?://telegram\.me/\+([A-Za-z0-9_-]+)',
        r't\.me/joinchat/([A-Za-z0-9_-]+)',
        r't\.me/\+([A-Za-z0-9_-]+)',
    ]
    
    invite_hash = None
    link_found = None
    
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            link_found = match.group(0)
            invite_hash = match.group(1)
            break
    
    # Skip kalau tidak ada link
    if not invite_hash:
        return
    
    try:
        # Import function
        from telethon.tl.functions.messages import ImportChatInviteRequest
        
        # Join grup
        result = await client(ImportChatInviteRequest(invite_hash))
        
        # Ambil info grup
        group_name = "Unknown"
        group_id = "Unknown"
        
        if hasattr(result, 'chats') and result.chats:
            chat = result.chats[0]
            group_name = chat.title
            group_id = chat.id
        
        # Reply ke sender (FEEDBACK LANGSUNG!)
        await event.reply(
            f"{get_emoji('check')} **SUKSES JOIN!** {get_emoji('success')}\n"
            f"📱 Grup: `{group_name}`\n"
            f"🆔 ID: `{group_id}`"
        )
        
        # Log ke logger group
        await log_to_group(
            f"{get_emoji('check')} **AUTO JOIN SUCCESS!** {get_emoji('success')}\n"
            f"====================\n"
            f"{get_emoji('group')} **Grup:** `{group_name}`\n"
            f"🆔 **ID:** `{group_id}`\n"
            f"🔗 **Link:** `{link_found}`\n"
            f"👤 **Dari:** {event.sender.first_name}\n"
            f"===================="
        )
        
        # AUTO SEND PAYMENT (BARU!)
        pay_msg = db.get('pay_msg')
        if pay_msg:
            try:
                await asyncio.sleep(1)  # Delay 1 detik
                await client.send_message(group_id, pay_msg)
                logger.info(f"Auto payment sent to {group_id}")
                
                # Notif ke sender
                await event.reply(
                    f"{get_emoji('check')} Payment sent to group!"
                )
            except Exception as e:
                logger.error(f"Error sending auto payment: {e}")
                await event.reply(
                    f"{get_emoji('warning')} Payment send failed: `{str(e)}`"
                )
        
        logger.info(f"Auto joined: {group_name} (ID: {group_id})")
        
    except FloodWaitError as e:
        # Convert seconds to human readable
        wait_seconds = e.seconds
        wait_minutes = wait_seconds // 60
        wait_hours = wait_minutes // 60
        
        # Format waktu tunggu
        if wait_hours > 0:
            wait_text = f"{wait_hours} jam {wait_minutes % 60} menit"
        elif wait_minutes > 0:
            wait_text = f"{wait_minutes} menit"
        else:
            wait_text = f"{wait_seconds} detik"
        
        # Reply ke pelanggan dengan penjelasan lengkap
        await event.reply(
            f"⏳ **MOHON MENUNGGU** ⏳\n"
            f"══════════════════════\n"
            f"📵 **Status:** Akun sedang limit join grup\n"
            f"⏰ **Waktu tunggu:** {wait_text}\n"
            f"══════════════════════\n"
            f"ℹ️ **Penjelasan:**\n"
            f"Akun MC sedang kena batas join grup dari Telegram.\n"
            f"Ini terjadi karena join terlalu banyak grup dalam waktu singkat.\n\n"
            f"🙏 **Mohon bersabar, bot akan otomatis join setelah waktu tunggu selesai.**\n\n"
            f"💡 **Saran:**\n"
            f"• Kirim ulang link setelah {wait_text}\n"
            f"• Atau tunggu konfirmasi dari admin\n\n"
            f"Terima kasih atas pengertiannya! 🙏"
        )
        
        # Log ke logger group
        await log_to_group(
            f"⏳ **AUTO JOIN - FLOODWAIT!**\n"
            f"====================\n"
            f"⏰ **Tunggu:** {wait_text} ({wait_seconds}s)\n"
            f"🔗 **Link:** `{link_found}`\n"
            f"👤 **Dari:** {event.sender.first_name}\n"
            f"===================="
        )
        
        logger.warning(f"FloodWait: {e.seconds}s from {event.sender.first_name}")
        
    except Exception as e:
        error_msg = str(e)
        
        if "INVITE_HASH_EXPIRED" in error_msg:
            await event.reply(f"{get_emoji('error')} Link expired!")
        elif "USER_ALREADY_PARTICIPANT" in error_msg:
            await event.reply(f"{get_emoji('warning')} Sudah join grup ini!")
        elif "CHANNELS_TOO_MUCH" in error_msg:
            await event.reply(f"{get_emoji('error')} Terlalu banyak grup! Leave beberapa dulu.")
        elif "INVITE_REQUEST_SENT" in error_msg:
            await event.reply(f"{get_emoji('info')} Request sent, tunggu admin approve.")
        else:
            await event.reply(f"{get_emoji('error')} Gagal join: `{error_msg}`")
        
        logger.error(f"Auto join error: {error_msg}")

# ═══════════════════════════════════════════════════════════
# EVENT HANDLERS - AUTOMATIC FEATURES
# ═══════════════════════════════════════════════════════════

@client.on(events.ChatAction)
async def chat_action_handler(event):
    """Handle join/leave events for auto-logger and auto-payment"""
    try:
        autojoin_enabled = db.get('autojoin_enabled', True)
        
        if not autojoin_enabled:
            return
        
        # Check if bot joined a group
        if event.user_joined or event.user_added:
            me = await client.get_me()
            user_id = event.user_id if event.user_joined else (await event.get_user()).id
            
            if user_id == me.id:
                chat = await event.get_chat()
                chat_title = getattr(chat, 'title', 'Unknown')
                chat_id = getattr(chat, 'id', 'Unknown')
                
                # Increment join counter & check limit
                current_count = await increment_join_count(chat_title, chat_id)
                
                # Log to logger group (SIMPLE!)
                log_msg = (
                    f"✅ **JOIN** `{chat_title}`\n"
                    f"📊 Today: `{current_count}/20`"
                )
                
                await log_to_group(log_msg)
                logger.info(f"Joined group: {chat_title} ({chat_id})")
                
                # Send payment message if enabled
                pay_msg = db.get('pay_msg')
                if pay_msg:
                    await asyncio.sleep(1)
                    try:
                        await client.send_message(event.chat_id, pay_msg)
                        logger.info(f"Payment sent to {chat_id}")
                    except Exception as e:
                        logger.error(f"Error sending payment: {e}")
        
        # Log member join/leave if enabled
        logmembers_enabled = db.get('logmembers_enabled', False)
        
        if logmembers_enabled:
            try:
                if event.user_joined:
                    try:
                        user = await event.get_user()
                        user_name = getattr(user, 'first_name', 'Unknown')
                        user_id = getattr(user, 'id', 0)
                        chat = await event.get_chat()
                        chat_title = getattr(chat, 'title', 'Unknown')
                        
                        await log_to_group(
                            f"{get_emoji('user')} **MEMBER JOINED**\n"
                            f"====================\n"
                            f"**User:** `{user_name}`\n"
                            f"🆔 **ID:** `{user_id}`\n"
                            f"{get_emoji('group')} **Group:** `{chat_title}`\n"
                            f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}"
                        )
                        logger.info(f"Member joined logged: {user_name} in {chat_title}")
                    except Exception as e:
                        logger.error(f"Error logging member join: {e}")
                    
                elif event.user_left or event.user_kicked:
                    try:
                        user = await event.get_user()
                        user_name = getattr(user, 'first_name', 'Unknown')
                        user_id = getattr(user, 'id', 0)
                        chat = await event.get_chat()
                        chat_title = getattr(chat, 'title', 'Unknown')
                        action = "KICKED" if event.user_kicked else "LEFT"
                        
                        await log_to_group(
                            f"{get_emoji('warning')} **MEMBER {action}**\n"
                            f"====================\n"
                            f"**User:** `{user_name}`\n"
                            f"🆔 **ID:** `{user_id}`\n"
                            f"{get_emoji('group')} **Group:** `{chat_title}`\n"
                            f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%H:%M:%S')}"
                        )
                        logger.info(f"Member {action.lower()} logged: {user_name} from {chat_title}")
                    except Exception as e:
                        logger.error(f"Error logging member {action.lower()}: {e}")
            except Exception as e:
                logger.error(f"Error in logmembers handler: {e}")
                
    except Exception as e:
        logger.error(f"Error in chat action handler: {e}")

@client.on(events.NewMessage(incoming=True))
async def afk_handler(event):
    """Handle AFK auto-reply when mentioned - DISABLED!"""
    return  # AFK DISABLED! Hapus baris ini untuk enable AFK
    
    try:
        afk_data = db.get('afk', {})
        
        if not afk_data.get('enabled'):
            return
        
        # Check if bot is mentioned
        me = await client.get_me()
        
        if event.mentioned or (event.is_private and event.sender_id != me.id):
            # Send AFK reply
            afk_reason = afk_data.get('reason', 'AFK')
            afk_time = afk_data.get('time', time.time())
            afk_duration = format_uptime(time.time() - afk_time)
            
            afk_text = (
                f"😴 **Currently AFK** {get_emoji('warning')}\n"
                f"====================\n"
                f"{get_emoji('note')} **Reason:** `{afk_reason}`\n"
                f"{get_emoji('stopwatch')} **Duration:** `{afk_duration}`\n"
                f"====================\n"
                f"I'll respond when I'm back!"
            )
            
            await safe_send(event.chat_id, afk_text, reply_to=event.id)
            logger.info(f"AFK reply sent in chat {event.chat_id}")
            
    except Exception as e:
        logger.error(f"Error in AFK handler: {e}")

@client.on(events.NewMessage(outgoing=True))
async def afk_disable_on_activity(event):
    """Disable AFK when user sends a message - DISABLED!"""
    return  # AFK DISABLED! Hapus baris ini untuk enable AFK
    
    try:
        afk_data = db.get('afk', {})
        
        if afk_data.get('enabled'):
            # Check if it's not an AFK command
            if not event.text or not event.text.startswith('.afk'):
                # Disable AFK
                afk_time = afk_data.get('time', time.time())
                afk_duration = format_uptime(time.time() - afk_time)
                
                afk_data['enabled'] = False
                db.set('afk', afk_data)
                
                # Notify user
                notif = await safe_send(
                    event.chat_id,
                    f"{get_emoji('check')} **AFK Mode Disabled**\n"
                    f"You were AFK for: `{afk_duration}`"
                )
                
                # Auto-delete notification after 3 seconds
                await asyncio.sleep(3)
                try:
                    await notif.delete()
                except:
                    pass
                
                logger.info("AFK mode disabled by user activity")
                
    except Exception as e:
        logger.error(f"Error in AFK disable handler: {e}")

# ═══════════════════════════════════════════════════════════
# MAIN STARTUP FUNCTION
# ═══════════════════════════════════════════════════════════

async def main():
    """Main bot startup function"""
    print("═" * 60)
    print(f"{get_emoji('robot')} KIRON USERBOT V50.0 PREMIUM EDITION {get_emoji('crown')}")
    print("═" * 60)
    
    try:
        # Create notes directory if not exists
        if not os.path.exists('notes'):
            os.makedirs('notes')
            logger.info("Created notes directory")
        
        await client.start()
        me = await client.get_me()
        
        print(f"{get_emoji('check')} Logged in as: {me.first_name}")
        print(f"{get_emoji('user')} Username: @{me.username}")
        print(f"🆔 User ID: {me.id}")
        print(f"{get_emoji('gem')} Premium: {me.premium if hasattr(me, 'premium') else 'Unknown'}")
        print("═" * 60)
        print(f"{get_emoji('note')} Type .help in any chat for commands")
        print("═" * 60)
        
        logger.info(f"Bot started as {me.username} (ID: {me.id})")
        
        # Initialize database stats if not exists
        stats = db.get('stats', {})
        if 'start_time' not in stats:
            stats['start_time'] = time.time()
            db.set('stats', stats)
        
        # Send startup notification to logger group
        await log_to_group(
            f"{get_emoji('rocket')} **BOT STARTED** {get_emoji('success')}\n"
            f"====================\n"
            f"{get_emoji('user')} **User:** `{me.first_name}`\n"
            f"🆔 **ID:** `{me.id}`\n"
            f"{get_emoji('gem')} **Premium:** {'Yes' if getattr(me, 'premium', False) else 'No'}\n"
            f"{get_emoji('stopwatch')} **Time:** {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
            f"====================\n"
            f"{get_emoji('shield')} *Ready to serve!*"
        )
        
        await client.run_until_disconnected()
        
    except KeyboardInterrupt:
        print(f"\n{get_emoji('warning')} Bot stopped by user")
        logger.info("Bot stopped by user (KeyboardInterrupt)")
        
    except Exception as e:
        print(f"{get_emoji('error')} Fatal error: {e}")
        logger.critical(f"Fatal error: {e}", exc_info=True)
        
    finally:
        await client.disconnect()
        print(f"{get_emoji('check')} Bot disconnected")

# ═══════════════════════════════════════════════════════════
# RUN BOT
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    try:
        # Import extension module V51
        try:
            import kiron_v51
            logger.info("Kiron V51 extension module loaded")
        except ImportError as e:
            logger.warning(f"Kiron V51 module not found: {e}")
        except Exception as e:
            logger.error(f"Error loading Kiron V51 module: {e}")
        
        client.loop.run_until_complete(main())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.critical(f"Critical error in main: {e}", exc_info=True)
        print(f"{get_emoji('error')} Critical error: {e}")

