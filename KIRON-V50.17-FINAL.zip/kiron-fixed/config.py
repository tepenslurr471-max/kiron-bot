"""
KIRON USERBOT - CONFIGURATION
Edit file ini dengan data Anda
"""

# ═══════════════════════════════════════════════════════════
# API CREDENTIALS
# Sudah diisi - JANGAN DIUBAH!
# ═══════════════════════════════════════════════════════════

API_ID = 38082140
API_HASH = '4798ae9861d21a498cde85354373849d'

# ═══════════════════════════════════════════════════════════
# LOGGER GROUP ID (WAJIB DIISI!)
# Buat grup, invite @userinfobot, copy ID grup
# Contoh: -1001234567890
# ═══════════════════════════════════════════════════════════

ID_GRUP_LOGGER = 0  # ← GANTI dengan ID grup logger Anda!

# ═══════════════════════════════════════════════════════════
# BROADCAST SETTINGS (Optional - Bisa dibiarkan)
# ═══════════════════════════════════════════════════════════

BC_DELAY = 3  # Delay antar pesan broadcast (detik)

# ═══════════════════════════════════════════════════════════
# SPAM SETTINGS (Optional - Bisa dibiarkan)  
# ═══════════════════════════════════════════════════════════

SPAM_DELAY = 0.5  # Delay antar pesan spam (detik)
