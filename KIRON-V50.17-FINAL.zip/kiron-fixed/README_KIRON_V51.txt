═══════════════════════════════════════════════════════════
  KIRON V51 - EXTENSION MODULE
═══════════════════════════════════════════════════════════

📦 WHAT IS THIS?
───────────────────────────────────────────────────────────
kiron_v51.py adalah file extension module yang menyambung
ke bot utama (bot.py) menggunakan: from __main__ import client

File ini berisi fitur tambahan yang bisa di-load secara
modular tanpa mengubah bot.py utama.

═══════════════════════════════════════════════════════════
✨ FEATURES
═══════════════════════════════════════════════════════════

1. CEK LIMIT SPAM (.ceklimit)
───────────────────────────────────────────────────────────
Command: .ceklimit

Fungsi:
→ Bot otomatis chat ke @SpamBot
→ Kirim perintah /start
→ Ambil response dari @SpamBot
→ Tampilkan ke user
→ Auto mark as read (tidak mengganggu)

Output:
✅ CEK LIMIT SPAM
══════════════════════
[Response dari @SpamBot]
══════════════════════
🤖 Source: @SpamBot

Use case:
→ Cek apakah kena limit spam
→ Cek kapan limit dibuka
→ Monitor status akun

═══════════════════════════════════════════════════════════
⚙️ CONFIGURATION
═══════════════════════════════════════════════════════════

COMMAND PREFIX:
───────────────────────────────────────────────────────────
cmd_prefix = "."

Bisa diganti dengan simbol lain:
cmd_prefix = "!"  → !ceklimit
cmd_prefix = "/"  → /ceklimit
cmd_prefix = "#"  → #ceklimit

Edit di file kiron_v51.py line 31.

═══════════════════════════════════════════════════════════
📁 FILE STRUCTURE
═══════════════════════════════════════════════════════════

kiron-fixed/
├── bot.py                  ← Main bot (V50.13)
├── kiron_v51.py           ← Extension module ⭐
├── config.py              ← Config
└── requirements.txt

═══════════════════════════════════════════════════════════
🚀 INSTALLATION
═══════════════════════════════════════════════════════════

STEP 1: Extract
───────────────────────────────────────────────────────────
$ unzip KIRON-V50.13-FINAL.zip
$ cd kiron-fixed

STEP 2: Check Files
───────────────────────────────────────────────────────────
$ ls
bot.py
kiron_v51.py  ← Harus ada!
config.py

STEP 3: Run Bot
───────────────────────────────────────────────────────────
$ python3 bot.py

Expected output:
═══════════════════════════════════════════════════
  KIRON V51 EXTENSION MODULE
═══════════════════════════════════════════════════
✅ Module loaded successfully!
📝 Command prefix: .
🤖 Commands available:
   • .ceklimit - Check spam limit
═══════════════════════════════════════════════════

STEP 4: Test Command
───────────────────────────────────────────────────────────
Di Telegram, ketik:
.ceklimit

Expected:
✅ CEK LIMIT SPAM
══════════════════════
[Response from @SpamBot]
══════════════════════
🤖 Source: @SpamBot

═══════════════════════════════════════════════════════════
🔧 HOW IT WORKS
═══════════════════════════════════════════════════════════

TECHNICAL FLOW:
───────────────────────────────────────────────────────────
1. User ketik: .ceklimit
2. Bot edit message: "⏳ Checking spam limit..."
3. Bot send message ke @SpamBot: "/start"
4. Bot wait 2 seconds
5. Bot get last message from @SpamBot
6. Bot mark as read (send_read_acknowledge)
7. Bot edit message dengan response
8. Done!

CODE EXPLANATION:
───────────────────────────────────────────────────────────
# Import bot from main
from __main__ import client as bot

# Command dengan prefix variable
@bot.on(events.NewMessage(
    outgoing=True,
    pattern=rf'^{cmd_prefix}ceklimit$'
))

# Send to SpamBot
await bot.send_message("@SpamBot", "/start")

# Get response
async for message in bot.iter_messages("@SpamBot", limit=1):
    response_text = message.text

# Mark as read (tidak mengganggu)
await bot.send_read_acknowledge("@SpamBot")

═══════════════════════════════════════════════════════════
🎯 USE CASES
═══════════════════════════════════════════════════════════

SCENARIO 1: Cek Limit Sebelum BC
───────────────────────────────────────────────────────────
Before: .bc [message]
Check: .ceklimit
→ Pastikan tidak kena limit
→ Baru broadcast

SCENARIO 2: Cek Limit Setelah Spam
───────────────────────────────────────────────────────────
After: .spam 100 test
Check: .ceklimit
→ Cek apakah kena limit
→ Tunggu jika perlu

SCENARIO 3: Monitoring Harian
───────────────────────────────────────────────────────────
Daily: .ceklimit
→ Monitor status akun
→ Prevent ban

═══════════════════════════════════════════════════════════
📝 ADDING NEW COMMANDS
═══════════════════════════════════════════════════════════

Want to add more commands? Easy!

STEP 1: Open kiron_v51.py
───────────────────────────────────────────────────────────
$ nano kiron_v51.py

STEP 2: Add New Command
───────────────────────────────────────────────────────────
@bot.on(events.NewMessage(
    outgoing=True,
    pattern=rf'^{cmd_prefix}yourcommand$'
))
async def your_command(event):
    try:
        await safe_edit(event, "Your response!")
    except Exception as e:
        logger.error(f"Error: {e}")

STEP 3: Save & Restart
───────────────────────────────────────────────────────────
Ctrl+X → Y → Enter
$ python3 bot.py

STEP 4: Test
───────────────────────────────────────────────────────────
.yourcommand

═══════════════════════════════════════════════════════════
⚠️ TROUBLESHOOTING
═══════════════════════════════════════════════════════════

ERROR: "This module must be imported from main bot"
───────────────────────────────────────────────────────────
Solution:
Don't run: python3 kiron_v51.py ❌
Run: python3 bot.py ✅

ERROR: "Module not found"
───────────────────────────────────────────────────────────
Solution:
Make sure both files in same directory:
bot.py
kiron_v51.py  ← Must be here!

ERROR: "@SpamBot not responding"
───────────────────────────────────────────────────────────
Solution:
1. Check manually: Open @SpamBot di Telegram
2. Send /start manually
3. Try .ceklimit again

ERROR: "Command not working"
───────────────────────────────────────────────────────────
Solution:
1. Check prefix: cmd_prefix = "." (line 31)
2. Restart bot: python3 bot.py
3. Check logs: kiron_bot.log

═══════════════════════════════════════════════════════════
📊 FEATURES SUMMARY
═══════════════════════════════════════════════════════════

V51 MODULE:
───────────────────────────────────────────────────────────
✅ .ceklimit - Check spam limit from @SpamBot
✅ Auto mark as read (tidak mengganggu)
✅ Modular design (easy to add commands)
✅ Variable prefix (mudah diganti)
✅ Import from main bot (no duplication)

MAIN BOT (V50.13):
───────────────────────────────────────────────────────────
✅ 61+ commands
✅ Admin grup (kick, mute, ban, etc)
✅ Rekap orderan (fixed timezone!)
✅ Broadcast (format lengkap)
✅ Save note (format lengkap)
✅ Autojoin + payment
✅ Music downloader
✅ All features working!

═══════════════════════════════════════════════════════════
💡 TIPS
═══════════════════════════════════════════════════════════

TIP 1: Customize Prefix
───────────────────────────────────────────────────────────
Edit line 31:
cmd_prefix = "!"

Save & restart → !ceklimit

TIP 2: Add Custom Commands
───────────────────────────────────────────────────────────
Add your own commands in kiron_v51.py
Keep bot.py clean!

TIP 3: Backup
───────────────────────────────────────────────────────────
$ cp kiron_v51.py kiron_v51.py.backup

═══════════════════════════════════════════════════════════

Module siap pakai! Run: python3 bot.py 🚀
