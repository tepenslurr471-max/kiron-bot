# 🤖 KIRON PREMIUM USERBOT V50.0

**Full Features Telegram Userbot - Siap Pakai!**

---

## ✨ 50+ COMMANDS AVAILABLE!

### Broadcast, Notes, Auto-Payment, Spam, Utilities, Group Management & More!

---

## 🚀 QUICK INSTALL (3 LANGKAH!)

```bash
# 1. Install
pip install telethon

# 2. Edit config.py
# Ganti ID_GRUP_LOGGER saja!

# 3. Run
python bot.py
```

---

## 📝 CARA PAKAI

### Setup Grup Logger:
1. Buat grup baru
2. Invite @userinfobot
3. Copy ID grup (dengan minus!)
4. Edit config.py → ID_GRUP_LOGGER

### Run Bot:
```bash
python bot.py
```

### Test:
```
.help     → Menu lengkap
.bc       → Broadcast (reply ke pesan)
.save     → Save note (reply ke pesan)
```

---

## 🎯 FITUR UNGGULAN

✅ BC dengan foto & format utuh
✅ Save note dengan format premium
✅ Auto-payment 1 detik
✅ 50+ commands
✅ No error, stable!

---

## ⚙️ SUDAH DI-SET:

✅ API_ID & API_HASH sudah diisi
✅ AFK disabled (hemat notifikasi)
✅ Payment delay 1 detik
✅ Logmembers improved

**Pembeli cukup isi ID_GRUP_LOGGER!**

---

## 📊 STATS

- Commands: 50+
- Lines: 1948
- Status: ✅ Stable
- Platform: Termux/VPS/PC

---

Terima kasih! 🚀
